import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class JDBCInterface extends JFrame {

	private JPanel controlPanel;
	private JTextArea textQueryArea;
	private JTextField lastName;
	private JButton queryButton;
	
	private JButton insertQ;
	private JTextField lastNameQ;
	private JTextField cityQ;
	private JTextField firstNameQ;
	private JTextField ageQ;
	
	private Connection conn;
	
	private PreparedStatement queryReturn;
	private PreparedStatement queryStmtLastName;
	private PreparedStatement queryStmt;

	private static final int FRAME_WIDTH = 600;
	private static final int FRAME_HEIGHT = 600;
	final int AREA_ROWS = 20;
	final int AREA_COLUMNS = 40;
   
   public JDBCInterface() {


		try {
			
			conn = DriverManager.getConnection("jdbc:sqlite:assignment.db");
			queryStmtLastName = conn.prepareStatement("Select * from People WHERE Last = ?");
			queryStmt = conn.prepareStatement("INSERT INTO People (Last, First, age, city) VALUES (?, ?, ?, ?) ");
			queryReturn = conn.prepareStatement("Select * from People");
			
			
		} catch (SQLException e) {
			System.err.println("Connection error: " + e);
			System.exit(1);
		}
		
	   createControlPanel();
	   queryButton.addActionListener(new QueryButtonListener());
	   insertQ.addActionListener(new InsertButtonListener());

	   textQueryArea = new JTextArea(
	            AREA_ROWS, AREA_COLUMNS);
	   textQueryArea.setEditable(false);
	   
	   /* scrollPanel is optional */
	   JScrollPane scrollPane = new JScrollPane(textQueryArea);
	   JPanel textPanel = new JPanel();
	   textPanel.add(scrollPane);
	   this.add(textPanel, BorderLayout.CENTER);
	   this.add(controlPanel, BorderLayout.NORTH);
	   queryButton.doClick();
   }
   
   private JPanel createControlPanel() {
	   
	   /* you are going to have to create a much more fully-featured layout */
	   
	   controlPanel = new JPanel();
	   GridLayout topGrid = new GridLayout(4,3);
	   controlPanel.setLayout(topGrid);
	   JPanel p1 = new JPanel();
	   JPanel p2 = new JPanel();


	   JLabel insertLastNameLabel = new JLabel("Last Name:");
	   JLabel insertFirstNameLabel = new JLabel("First Name:");
	   lastNameQ = new JTextField(12);
	   firstNameQ = new JTextField(8);
	   p1.add(insertLastNameLabel, BorderLayout.CENTER);
	   p1.add(lastNameQ);
	   p1.add(insertFirstNameLabel, BorderLayout.CENTER);
	   p1.add(firstNameQ);

	   JLabel insertCityLabel = new JLabel("City:");
	   cityQ = new JTextField(15);
	   JLabel insertAgeLabel = new JLabel("Age:");
	   ageQ = new JTextField(2);
	   
	   p2.add(insertAgeLabel);
	   p2.add(ageQ, BorderLayout.SOUTH);
	   p2.add(insertCityLabel);
	   p2.add(cityQ, BorderLayout.SOUTH);

	   insertQ = new JButton("Insert");
	   JPanel buttonP = new JPanel();
	   JPanel buttonP2 = new JPanel();

	   buttonP.add(insertQ);
	   JPanel p3 = new JPanel();
	   p3.add(buttonP);
	   controlPanel.add(p1,BorderLayout.NORTH);
	   controlPanel.add(p2,BorderLayout.CENTER);
	   JPanel p4 = new JPanel();
	   JLabel lastN = new JLabel("Last Name:");
	   lastName = new JTextField(12);
	   

	   controlPanel.add(p3,BorderLayout.SOUTH);
	   p4.add(lastN);
	   p4.add(lastName);
	   queryButton = new JButton("Execute Query");
	   buttonP2.add(queryButton);
	   p4.add(buttonP2,BorderLayout.SOUTH);
	   controlPanel.add(p4);
	   return controlPanel;
   }
   
   class InsertButtonListener implements ActionListener {
	   public void actionPerformed(ActionEvent event) {
		   /* You will have to implement this */
		   
		   try {
				String first_name = firstNameQ.getText();
				String last_name = lastNameQ.getText();
				
				String age = ageQ.getText();
				String city = cityQ.getText();

				if(Integer.parseInt(age) > 99) {
					JOptionPane.showMessageDialog(controlPanel, "age should be <100", "Error", 1);
					return;
				}
				if (first_name.trim().isEmpty() || last_name.trim().isEmpty() || age.trim().isEmpty() || city.trim().isEmpty()) {
					JOptionPane.showMessageDialog(controlPanel, "Fill all boxes", "Error", 1);
					return;
				}
				PreparedStatement st = queryStmt;
				
				st.setString(1, last_name.toLowerCase());
				st.setString(2, first_name.toLowerCase());
				
				st.setInt(3, Integer.parseInt(age));
				st.setString(4, city.toLowerCase());
				
				st.executeUpdate();
				
				lastNameQ.setText(null);
				lastName.setText(null);
				firstNameQ.setText(null);
				ageQ.setText(null);
				cityQ.setText(null);
				
				queryButton.doClick();

		   } 
		   
		   	catch (NumberFormatException exception) {
		   		
			JOptionPane.showMessageDialog(controlPanel, "age not number", "error", 1);
			
		   }
		   
		   	catch (SQLException e) {
		   		
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	   }
   }
   
   class QueryButtonListener implements ActionListener {
	   public void actionPerformed(ActionEvent event)
       {
		   /* as far as the columns, it is totally acceptable to
		    * get all of the column data ahead of time, so you only
		    * have to do it once, and just reprint the string
		    * in the text area.
		    */
		   
		   /* you want to change things here so that if the text of the 
		    * last name query field is empty, it should query for all rows.
		    * 
		    * For now, if the last name query field is blank, it will execute:
		    * SELECT * FROM People WHERE Last=''
		    * which will give no results
		    */
		   try {
			   textQueryArea.setText("");
			   String lastNameText = lastName.getText();
			   
			   PreparedStatement stmt;
			   
			   
			   if (lastNameText.trim().isEmpty()) {
					stmt = queryReturn;
				} else {
					stmt = queryStmtLastName;
					stmt.setString(1, lastNameText.toLowerCase());
				}
			   
				ResultSet rset = stmt.executeQuery();
				ResultSetMetaData rsmd = rset.getMetaData();
				int numColumns = rsmd.getColumnCount();
				System.out.println("numcolumns is "+ numColumns);

				String column = "";
				
				for (int num = 1; num <= numColumns; num++) {
					
					column = column + rsmd.getColumnName(num) + "\t";
					 
				}

				column += "\n";
	
				String rowString = column;
				while (rset.next()) {
					for (int i=1; i <= numColumns;i++) {
						Object o = rset.getObject(i);
						rowString += o.toString() + "\t";
					}
					rowString += "\n";
				}
				System.out.print("rowString  is  " + rowString);
				textQueryArea.setText(rowString);
		   } catch (SQLException e) {
			   // TODO Auto-generated catch block
			   e.printStackTrace();
		   }
       }
   }
    
   public static void main(String[] args)
	{  
	   JFrame frame = new JDBCInterface();
	   frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
	   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   frame.setVisible(true);      
	}
}
